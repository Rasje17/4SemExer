public interface PQ {
    public Element extractMin();
    public void insert(Element e);
}