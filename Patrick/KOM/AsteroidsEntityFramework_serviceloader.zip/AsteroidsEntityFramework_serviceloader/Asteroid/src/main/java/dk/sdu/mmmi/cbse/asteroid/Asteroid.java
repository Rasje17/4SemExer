package dk.sdu.mmmi.cbse.asteroid;

import dk.sdu.mmmi.cbse.common.data.Entity;

public class Asteroid extends Entity {
    
    public Asteroid() {
        setShapeX(new float[8]);
        setShapeY(new float[8]);
    }
    
}