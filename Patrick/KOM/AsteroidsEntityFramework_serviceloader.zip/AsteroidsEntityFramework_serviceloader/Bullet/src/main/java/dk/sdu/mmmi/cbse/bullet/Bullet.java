package dk.sdu.mmmi.cbse.bullet;

import dk.sdu.mmmi.cbse.common.data.Entity;

public class Bullet extends Entity {
    
    public Bullet() {
        setShapeX(new float[2]);
        setShapeY(new float[2]);
    }
}